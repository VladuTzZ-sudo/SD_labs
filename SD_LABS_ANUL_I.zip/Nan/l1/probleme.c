/*
*	Created by Nan Mihai on 20.02.2020
*	Copyright (c) 2016 Nan Mihai. All rights reserved.
*	Laborator 1 - Structuri de date (Recursivitate I)
*	Grupa 311CC
*	Facultatea de Automatica si Calculatoare
*	Anul Universitar 2018-2019, Seria CC
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define sd_assert(message, test) \
	do                           \
	{                            \
		if (!(test))             \
			return message;      \
	} while (0)

#define sd_run_test(test, score)  \
	do                            \
	{                             \
		char *message = test();   \
		tests_run++;              \
		if (message)              \
			return message;       \
		else                      \
			total_score += score; \
	} while (0)

int tests_run = 0;
int total_score = 0;

//Problema 1 - 2 puncte
int putere(int baza, int exponent)
{
	if (exponent == 0)
		return 1;
	else
	{
		return baza * putere(baza, exponent - 1);
	}
}

//Problema 2 - 2 puncte
int palindrom(char *sir, int start, int end)
{
	if (start > end)
		return 1;
	else
	{
		if (sir[start] == sir[end])
			return palindrom(sir, start + 1, end - 1);
	}
	return 0;
}
//Problema 3 - 1 punct
int recurenta(int pozitie)
{
	if (pozitie == 0)
		return 0;
	if (pozitie == 1)
		return 1;
	return 4 * recurenta(pozitie - 1) - 3 * recurenta(pozitie - 2) + 1;
}

//Problema 4 - 2 puncte
int euclid(int a, int b)
{
	int r = a % b;
	while (r != 0)
	{
		a = b;
		b = r;
		r = a % b;
	}
	return b;
}

//Problema 5 - 1 punct
int fibonacci(int pozitie)
{
	if (pozitie == 0)
		return 0;
	if (pozitie == 1)
		return 1;
	return fibonacci(pozitie - 1) + fibonacci(pozitie - 2);
}

//Problema 6 - 2 puncte
int M(int n);
int F(int n);
int M(int n)
{
	if (n == 0)
		return 0;
	if (n > 0)
		return n - F(M(n - 1));
}

int F(int n)
{
	if (n == 0)
		return 1;
	if (n > 0)
		return n - M(F(n - 1));
}

static char *test_problema1()
{
	sd_assert("Problema1 - Test1 picat", putere(2, 3) == 8);
	sd_assert("Problema1 - Test2 picat", putere(15262078, 0) == 1);
	sd_assert("Problema1 - Test3 picat", putere(8, 4) == putere(2, 12));
	sd_assert("Problema1 - Test4 picat", putere(4, 4) == putere(2, 8));
	sd_assert("Problema1 - Test5 picat", putere(3, 2) == putere(2, 2) + putere(5, 1));
	return 0;
}

static char *test_problema2()
{
	sd_assert("Problema2 - Test1 picat", palindrom("9", 0, 0));
	sd_assert("Problema2 - Test2 picat", !palindrom("12345", 0, 4));
	sd_assert("Problema2 - Test3 picat", palindrom("ana", 0, 2));
	sd_assert("Problema2 - Test4 picat", palindrom("murdrum", 0, 6));
	sd_assert("Problema2 - Test5 picat", palindrom("1221", 0, 3));
	sd_assert("Problema2 - Test6 picat", !palindrom("ana are mere", 0, 11));
	sd_assert("Problema2 - Test7 picat", palindrom("hadedah", 0, 6));
	return 0;
}

static char *test_problema3()
{
	sd_assert("Problema3 - Test1 picat", recurenta(7) == -3 * recurenta(5) + 4 * recurenta(6) + 1);
	sd_assert("Problema3 - Test2 picat", recurenta(12) == 4 * recurenta(11) - 3 * recurenta(10) + 1);
	sd_assert("Problema3 - Test3 picat", recurenta(13) == 1195735);
	return 0;
}

static char *test_problema4()
{
	sd_assert("Problema4 - Test1 picat", euclid(8, 2) == 2);
	sd_assert("Problema4 - Test2 picat", euclid(124, 250) == 2);
	sd_assert("Problema4 - Test3 picat", euclid(947, 881) == 1);
	sd_assert("Problema4 - Test4 picat", euclid(51555, 915240) == euclid(915240, 51555));
	return 0;
}

static char *test_problema5()
{
	sd_assert("Problema5 - Test1 picat", fibonacci(7) == fibonacci(5) + fibonacci(6));
	sd_assert("Problema5 - Test2 picat", fibonacci(12) == fibonacci(11) + fibonacci(10));
	sd_assert("Problema5 - Test3 picat", fibonacci(13) == 233);
	return 0;
}

static char *test_problema6()
{
	sd_assert("Problema6 - Test1 picat", M(3) == 2 && F(3) == 2);
	sd_assert("Problema6 - Test2 picat", M(4) == 2 && F(4) == 3);
	sd_assert("Problema6 - Test3 picat", M(5) == 3 && F(5) == 3);
	sd_assert("Problema6 - Test4 picat", M(6) == 4 && F(6) == 4);
	sd_assert("Problema6 - Test5 picat", M(11) == 7 && F(11) == 7);
	return 0;
}

static char *all_tests()
{
	sd_run_test(test_problema1, 2);
	sd_run_test(test_problema2, 2);
	sd_run_test(test_problema3, 1);
	sd_run_test(test_problema4, 2);
	sd_run_test(test_problema5, 1);
	sd_run_test(test_problema6, 2);
	return 0;
}

static char *selective_tests(int argc, char **argv)
{
	int i;
	int viz[7] = {0};
	for (i = 1; i < argc; i++)
	{
		if (viz[atoi(argv[i])])
		{
			continue;
		}
		if (!strcmp(argv[i], "1"))
		{
			viz[1] = 1;
			sd_run_test(test_problema1, 2);
		}
		else if (!strcmp(argv[i], "2"))
		{
			viz[2] = 1;
			sd_run_test(test_problema2, 1);
		}
		else if (!strcmp(argv[i], "3"))
		{
			viz[3] = 1;
			sd_run_test(test_problema3, 2);
		}
		else if (!strcmp(argv[i], "4"))
		{
			viz[4] = 1;
			sd_run_test(test_problema4, 2);
		}
		else if (!strcmp(argv[i], "5"))
		{
			viz[5] = 1;
			sd_run_test(test_problema5, 1);
		}
		else if (!strcmp(argv[i], "6"))
		{
			viz[6] = 1;
			sd_run_test(test_problema6, 2);
		}
	}
	return 0;
}

int main(int argc, char **argv)
{
	srand(time(NULL));
	char *result;
	if (argc == 1)
	{
		result = all_tests();
		if (result != 0)
		{
			printf("%s\n", result);
		}
		else
		{
			printf("Toate testele au trecut! Felicitari!\n");
		}
	}
	else
	{
		result = selective_tests(argc, argv);
		if (result != 0)
		{
			printf("%s\n", result);
		}
		else
		{
			printf("Toate testele selectate au trecut!\n");
		}
	}
	printf("Punctajul obtinut este: %d\n", total_score);
	printf("Teste rulate: %d\n", tests_run);
	return result != 0;
}
