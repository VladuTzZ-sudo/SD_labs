/*
*	Created by Nan Mihai on 02.03.2017
*	Copyright (c) 2017 Nan Mihai. All rights reserved.
*	Laborator 2 - Structuri de date
*	Grupa - 311aCC
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define sd_assert(message, test) \
    do                           \
    {                            \
        if (!(test))             \
            return message;      \
    } while (0)

#define sd_run_test(test, score)  \
    do                            \
    {                             \
        char *message = test();   \
        tests_run++;              \
        if (message)              \
            return message;       \
        else                      \
            total_score += score; \
    } while (0)

int tests_run = 0;
int total_score = 0;

typedef struct pair
{
    int min, max;
} * Pair;

//Problema 1
int suma_cifre(int nr)
{
    if (nr > 9)
    {
        return nr % 10 + suma_cifre(nr / 10);
    }
    else
    {
        return nr;
    }
}

//Problema 2
int binary_search(int *v, int start, int end, int x)
{
    if (start == end)
    {
        if (v[start] == x)
            return start;
        else
        {
            return -1;
        }
    }
    int mij;
    mij = (start + end) / 2;
    if (v[mij] < x)
        return binary_search(v, mij + 1, end, x);
    return binary_search(v, start, mij, x);
}

//Problema 3
Pair min_max(int *v, int start, int end)
{
    Pair p = (Pair)malloc(sizeof(struct pair));
    p->min = v[start];
    p->max = v[start];
    if (start == end)
    {
        p->min = v[start];
        p->max = v[start];
        return p;
    }
    else
    {
        int mij = (start + end) / 2;
        Pair x = (Pair)malloc(sizeof(struct pair));
        Pair y = (Pair)malloc(sizeof(struct pair));
        x = min_max(v, mij + 1, end);
        y = min_max(v, start, mij);
        if (x->min < y->min)
        {
            p->min = x->min;
        }
        else
        {
            p->min = y->min;
        }
        if (x->max < y->max)
        {
            p->max = y->max;
        }
        else
        {
            p->max = x->max;
        }
    }
    return p;
}

//Problema 4
int partition(int *v, int start, int end)
{
    int pivot = start;
    int index = start;
    int i;
    for (i = start + 1; i <= end; i++)
        if (v[i] < v[pivot])
        {
            index++;
            int aux = v[i];
            v[i] = v[index];
            v[index] = aux;
        }
    int aux = v[start];
    v[start] = v[index];
    v[index] = aux;
    return index;
}
void quick_sort(int *v, int start, int end)
{
    //TODO 4
    if (start < end)
    {
        int pivot = partition(v, start, end);
        quick_sort(v, start, pivot - 1);
        quick_sort(v, pivot + 1, end);
    }
}

//Problema 5
int suma(int *v, int size)
{
    if (size == 1)
    {
        return v[0];
    }
    else
    {
        int r1, r2;
        if (size % 2 == 1)
        {
            int mij = size / 2 + 1;
            r1 = suma(v, mij - 1);
            r2 = suma(v + mij, mij - 1);
        }
        else
        {
            int mij = size / 2;
            r1 = suma(v, mij);
            r2 = suma(v + mij, mij);
        }
        return r1 + r2;
    }
}

static char *test_problema1()
{
    sd_assert("Problema1 - Test1 picat", suma_cifre(7) == 7);
    sd_assert("Problema1 - Test2 picat", suma_cifre(50) == 5);
    sd_assert("Problema1 - Test3 picat", suma_cifre(99) == 18);
    sd_assert("Problema1 - Test4 picat", suma_cifre(11111) == 5);
    sd_assert("Problema1 - Test5 picat", suma_cifre(20202022) == 10);
    return 0;
}

static char *test_problema2()
{
    int i, *v = (int *)malloc(100 * sizeof(int));
    for (i = 0; i < 50; i++)
    {
        v[i] = 2 * i;
    }
    sd_assert("Problema2 - Test1 picat", binary_search(v, 0, 49, 15) == -1);
    sd_assert("Problema2 - Test2 picat", binary_search(v, 0, 49, 20) == 10);
    sd_assert("Problema2 - Test3 picat", binary_search(v, 0, 49, 33) == -1);
    sd_assert("Problema2 - Test4 picat", binary_search(v, 0, 49, 34) == 17);
    sd_assert("Problema2 - Test5 picat", binary_search(v, 0, 49, 84) == 42);
    sd_assert("Problema2 - Test6 picat", binary_search(v, 0, 49, 0) == 0);
    sd_assert("Problema2 - Test7 picat", binary_search(v, 0, 49, -8912) == -1);
    for (i = 0; i < 10; i++)
    {
        v[i] = 10;
    }
    sd_assert("Problema2 - Test8 picat", binary_search(v, 0, 9, 10) == 0);
    for (i = 0; i < 10; i++)
    {
        if (i < 7)
        {
            v[i] = i;
        }
        else
        {
            v[i] = 15;
        }
    }
    sd_assert("Problema2 - Test9 picat", binary_search(v, 0, 9, 15) == 7);
    free(v);
    return 0;
}

static char *test_problema3()
{
    int i, min, max, *v = (int *)malloc(100 * sizeof(int));
    min = 101, max = -1;
    for (i = 0; i < 10; i++)
    {
        v[i] = rand() % 100;
        if (v[i] < min)
        {
            min = v[i];
        }
        if (v[i] > max)
        {
            max = v[i];
        }
    }
    Pair p;
    p = min_max(v, 0, 9);
    sd_assert("Problema3 - Test1 picat", p->min == min && p->max == max);
    min = 10001;
    max = -1;
    for (i = 0; i < 50; i++)
    {
        v[i] = rand() % 1000;
        if (v[i] < min)
        {
            min = v[i];
        }
        if (v[i] > max)
        {
            max = v[i];
        }
    }
    p = min_max(v, 0, 49);
    sd_assert("Problema3 - Test2 picat", p->min == min && p->max == max);
    min = 10001;
    max = -1;
    for (i = 0; i < 100; i++)
    {
        v[i] = rand() % 1000;
        if (v[i] < min)
        {
            min = v[i];
        }
        if (v[i] > max)
        {
            max = v[i];
        }
    }
    p = min_max(v, 0, 99);
    sd_assert("Problema3 - Test3 picat", p->min == min && p->max == max);
    free(v);
    return 0;
}

int isSorted(int *v, int nr)
{
    int i;
    for (i = 0; i < nr - 1; i++)
    {
        if (v[i] > v[i + 1])
        {
            return 0;
        }
    }
    return 1;
}

static char *test_problema4()
{
    int i, *v = (int *)malloc(100 * sizeof(int));
    for (i = 0; i < 10; i++)
    {
        v[i] = rand();
    }
    quick_sort(v, 0, 9);
    sd_assert("Problema4 - Test1 picat", isSorted(v, 10) == 1);
    for (i = 0; i < 50; i++)
    {
        v[i] = rand();
    }
    quick_sort(v, 0, 49);
    sd_assert("Problema4 - Test2 picat", isSorted(v, 50) == 1);
    for (i = 0; i < 50; i++)
    {
        if (i % 3 == 0)
            v[i] = -rand();
    }
    quick_sort(v, 0, 49);
    sd_assert("Problema4 - Test3 picat", isSorted(v, 50) == 1);
    for (i = 0; i < 100; i++)
    {
        if (i % 5 == 0)
            v[i] = -rand();
    }
    quick_sort(v, 0, 99);
    sd_assert("Problema4 - Test4 picat", isSorted(v, 50) == 1);
    free(v);
    return 0;
}

static char *test_problema5()
{
    int i, *v = (int *)malloc(100 * sizeof(int));
    for (i = 0; i < 7; i++)
    {
        v[i] = i + 1;
    }
    sd_assert("Problema 5 - Test1 picat", suma(v, 7) == 16);
    for (i = 0; i < 13; i++)
    {
        v[i] = i;
    }
    int TOPO = suma(v, 13);
    printf("%d\n", TOPO);
   // sd_assert("Problema 5 - Test2 picat", suma(v, 13) == 46);
    for (i = 0; i < 50; i++)
    {
        v[i] = i;
    }
    int TOPO2 = suma(v, 13);
    printf("%d\n", TOPO2);
    sd_assert("Problema 5 - Test3 picat", suma(v, 50) == 763);
    free(v);
    return 0;
}

static char *all_tests()
{
    sd_run_test(test_problema1, 1);
    sd_run_test(test_problema2, 2);
    sd_run_test(test_problema3, 2);
    sd_run_test(test_problema4, 3);
    sd_run_test(test_problema5, 2);
    return 0;
}

static char *selective_tests(int argc, char **argv)
{
    int i;
    int viz[6] = {0};
    for (i = 1; i < argc; i++)
    {
        if (viz[atoi(argv[i])])
        {
            continue;
        }
        if (!strcmp(argv[i], "1"))
        {
            viz[1] = 1;
            sd_run_test(test_problema1, 1);
        }
        else if (!strcmp(argv[i], "2"))
        {
            viz[2] = 1;
            sd_run_test(test_problema2, 2);
        }
        else if (!strcmp(argv[i], "3"))
        {
            viz[3] = 1;
            sd_run_test(test_problema3, 2);
        }
        else if (!strcmp(argv[i], "4"))
        {
            viz[4] = 1;
            sd_run_test(test_problema4, 3);
        }
        else if (!strcmp(argv[i], "5"))
        {
            viz[5] = 1;
            sd_run_test(test_problema5, 2);
        }
    }
    return 0;
}

int main(int argc, char **argv)
{
    srand(time(NULL));
    char *result;
    if (argc == 1)
    {
        result = all_tests();
        if (result != 0)
        {
            printf("%s\n", result);
        }
        else
        {
            printf("Toate testele au trecut! Felicitari!\n");
        }
    }
    else
    {
        result = selective_tests(argc, argv);
        if (result != 0)
        {
            printf("%s\n", result);
        }
        else
        {
            printf("Toate testele selectate au trecut!\n");
        }
    }
    printf("Punctajul obtinut este: %d\n", total_score);
    printf("Teste rulate: %d\n", tests_run);
    return result != 0;
}
