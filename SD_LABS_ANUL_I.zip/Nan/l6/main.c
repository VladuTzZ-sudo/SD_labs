/*
*	Created by Nan Mihai on 24.03.2020
*	Copyright (c) 2020 Nan Mihai. All rights reserved.
*	Laborator 6 - Structuri de date
*	Grupa 312CCb
*	Facultatea de Automatica si Calculatoare
*	Anul Universitar 2019-2020, Seria CC
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "tree.h"

#define sd_assert(message, test) \
	do { \
		if (!(test)) \
			return message; \
	} while (0)

#define sd_run_test(test, score) \
	do { \
		char *message = test(); \
		tests_run++; \
		if (message) \
			return message; \
		else \
			total_score += score; \
	} while (0)

int tests_run = 0;
float total_score = 0;

int test1[] = {9, 7, 5, 9, 4, 10, 6, 8, -8, 12};
int test2[] = {11, 9, 7, 25, 12, 29, 27, 8, 5, 1, 35, 26};
int test3[] = {26, 50, 150, 35, 175, 155, 100, 95, 9, 15, 45, 40, 4, 47, 98, \
	97, 99, 90, 200, 50, 68, 35, 39, 37, 44, 43, 46};

int checkBST(Tree node) { 
	if (node == NULL) 
		return 1;
	if (node->left != NULL && node->left->value > node->value)
		return 0; 
	if (node->right != NULL && node->right->value < node->value) 
		return 0; 
	if (!checkBST(node->left) || !checkBST(node->right)) 
		return 0; 
	return 1; 
}

void bst_print_dot_aux(Tree node, FILE* stream) {
    static int nullcount = 0;

    if (node->left) {
        fprintf(stream, "    %d -> %d;\n", node->value, node->left->value);
        bst_print_dot_aux(node->left, stream);
    }
    if (node->right) {
        fprintf(stream, "    %d -> %d;\n", node->value, node->right->value);
        bst_print_dot_aux(node->right, stream);
    }
}

void bst_print_dot(Tree tree, FILE* stream, int type) {
    fprintf(stream, "digraph BST {\n");
    if (type == 1)
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=green];\n");
    else
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=blue];\n");
    if (!tree)
        fprintf(stream, "\n");
    else if (!tree->right && !tree->left)
        fprintf(stream, "    %d;\n", tree->value);
    else
        bst_print_dot_aux(tree, stream);
    fprintf(stream, "}\n");
}

void bst_print_dot_aux_min(Tree node, FILE* stream) {
    static int nullcount = 0;

    if (!node)
    	return;
    if (node->left) {
        bst_print_dot_aux_min(node->left, stream);
    } else {
    	fprintf(stream, "    %d [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n", node->value);
    }
    
}

void bst_print_dot_aux_max(Tree node, FILE* stream) {
    static int nullcount = 0;

    if (!node)
    	return;
    if (node->right) {
        bst_print_dot_aux_max(node->right, stream);
    } else {
    	fprintf(stream, "    %d [fontname=\"Arial\", shape=circle, style=filled, fillcolor=green];\n", node->value);
    }
    
}

void bst_print_dot_minmax(Tree tree, FILE* stream, int type) {
    fprintf(stream, "digraph BST {\n");
    if (type == 1)
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=red];\n");
    else
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=blue];\n");
    if (!tree)
        fprintf(stream, "\n");
    else if (!tree->right && !tree->left)
        fprintf(stream, "    %d;\n", tree->value);
    else {
        bst_print_dot_aux(tree, stream);
    	bst_print_dot_aux_min(tree, stream);
    	bst_print_dot_aux_max(tree, stream);
    }
    fprintf(stream, "}\n");
}

void bst_print_dot_values(Tree tree, FILE* stream, int type, int min, int max) {
    fprintf(stream, "digraph BST {\n");
    if (type == 1)
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=red];\n");
    else
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=blue];\n");
    if (!tree)
        fprintf(stream, "\n");
    else if (!tree->right && !tree->left)
        fprintf(stream, "    %d;\n", tree->value);
    else {
        bst_print_dot_aux(tree, stream);
    	fprintf(stream, "    %d [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n", min);
    	if (max != -1)
    		fprintf(stream, "    %d [fontname=\"Arial\", shape=circle, style=filled, fillcolor=green];\n", max);
    }
    fprintf(stream, "}\n");
}

void bst_print_dot_lca(Tree tree, FILE* stream, int type, int value1, int value2, int lca) {
    fprintf(stream, "digraph BST {\n");
    if (type == 1)
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=red];\n");
    else
    	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=blue];\n");
    if (!tree)
        fprintf(stream, "\n");
    else if (!tree->right && !tree->left)
        fprintf(stream, "    %d;\n", tree->value);
    else {
        bst_print_dot_aux(tree, stream);
    	fprintf(stream, "    %d [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n", value1);
    	fprintf(stream, "    %d [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n", value2);
    	fprintf(stream, "    %d [fontname=\"Arial\", shape=circle, style=filled, fillcolor=green];\n", lca);
    }
    fprintf(stream, "}\n");
}

static char *test_insert() {
	Tree tree = NULL;
	FILE *f;
	int i;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
	}
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_tree1.png");
	sd_assert("Problema1 - Test1 insert picat", checkBST(tree) && tree != NULL);
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
	}
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_tree2.png");
	sd_assert("Problema1 - Test2 insert picat", checkBST(tree) && tree != NULL);
	freeTree(&tree);
	
	tree = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
	}
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_tree3.png");
	sd_assert("Problema1 - Test3 insert picat", checkBST(tree) && tree != NULL);
	freeTree(&tree);
	return 0;
}

static char *test_minmax() {
	Tree tree = NULL;
	int min, max, i;
	FILE *f;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
	}
	min = minimum(tree);
	max = maximum(tree);
	f = fopen("test.dot", "w");
	bst_print_dot_values(tree, f, 1, min, max);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_minmax1.png");
	sd_assert("Problema1 - Test1 min picat", min == -8);
	sd_assert("Problema1 - Test1 max picat", max == 12);
	freeTree(&tree);
	
	tree = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
	}
	min = minimum(tree);
	max = maximum(tree);
	f = fopen("test.dot", "w");
	bst_print_dot_values(tree, f, 1, min, max);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_minmax2.png");
	sd_assert("Problema1 - Test2 min picat", min == 1);
	sd_assert("Problema1 - Test2 max picat", max == 35);
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
	}
	min = minimum(tree);
	max = maximum(tree);
	f = fopen("test.dot", "w");
	bst_print_dot_values(tree, f, 1, min, max);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_minmax3.png");
	sd_assert("Problema1 - Test3 min picat", min == 4);
	sd_assert("Problema1 - Test3 max picat", max == 200);
	freeTree(&tree);

	return 0;
}

static char *test_contains() {
	Tree tree = NULL;
	int i;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
	}
	sd_assert("Problema1 - Test1 contains picat", contains(tree, 7) && contains(tree, 10) && contains(tree, 12) &&
												  !contains(tree, 2) && !contains(tree, 20) && contains(tree, 6));
	freeTree(&tree);
	
	tree = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
	}
	sd_assert("Problema1 - Test2 contains picat", contains(tree, 25) && contains(tree, 26) && contains(tree, 1) &&
												  contains(tree, 35) && !contains(tree, 24) && !contains(tree, 28));
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
	}
	sd_assert("Problema1 - Test3 contains picat", contains(tree, 155) && contains(tree, 99) && contains(tree, 43));
	freeTree(&tree);

	return 0;
}

static char *test_height() {
	Tree tree = NULL;
	int i;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
	}
	sd_assert("Problema2 - Test1 height picat", height(tree) == 4);
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
	}
	sd_assert("Problema2 - Test2 height picat", height(tree) == 5);
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
	}
	sd_assert("Problema2 - Test3 height picat", height(tree) == 6);
	freeTree(&tree);

	return 0;
}

static char *test_size() {
	Tree tree = NULL;
	int i;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
	}
	sd_assert("Problema3 - Test1 size picat", size(tree) == test1[0]);
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
	}
	sd_assert("Problema3 - Test2 size picat", size(tree) == test2[0]);
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
	}
	sd_assert("Problema3 - Test3 size picat", size(tree) == test3[0] - 2);
	freeTree(&tree);

	return 0;
}

int areMirrorTrees(Tree root1, Tree root2) {
	if (root1 == NULL && root2 == NULL)
		return 1;
	if (root1 == NULL || root2 == NULL)
		return 0;
	if (root1->value != root2->value)
		return 0;
	int res1, res2;
	res1 = areMirrorTrees(root1->left, root2->right);
	res2 = areMirrorTrees(root1->right, root2->left);
	return res1 && res2;
}

static char *test_mirror() {
	Tree tree = NULL, result = NULL;
	int i;
	FILE *f;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
		result = insert(result, test1[i]);
	}
	mirror(tree);
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 3);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_mirror1.png");
	sd_assert("Problema4 - Test1 mirror picat", areMirrorTrees(tree, result));
	freeTree(&tree);
	freeTree(&result);

	tree = NULL;
	result = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
		result = insert(result, test2[i]);
	}
	mirror(tree);
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 3);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_mirror2.png");
	sd_assert("Problema4 - Test2 mirror picat", areMirrorTrees(tree, result));
	freeTree(&tree);
	freeTree(&result);

	tree = NULL;
	result = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
		result = insert(result, test3[i]);
	}
	mirror(tree);
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 3);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_mirror3.png");
	sd_assert("Problema4 - Test3 mirror picat", areMirrorTrees(tree, result));
	freeTree(&tree);
	freeTree(&result);

	return 0;
}

static char *test_delete() {
	Tree tree = NULL;
	int value, i;
	FILE *f;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
	}
	value = 12;
	f = fopen("test.dot", "w");
	bst_print_dot_values(tree, f, 1, value, -1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_delete1_before.png");
	tree = delete(tree, value);
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_delete1_after.png");
	sd_assert("Problema5 - Test1 delete picat", height(tree) == 4 && tree != NULL && checkBST(tree) && !contains(tree, value));
	freeTree(&tree);
	
	tree = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
	}
	value = 29;
	f = fopen("test.dot", "w");
	bst_print_dot_values(tree, f, 1, value, -1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_delete2_before.png");
	tree = delete(tree, value);
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_delete2_after.png");
	sd_assert("Problema5 - Test2 delete picat", height(tree) == 5 && tree != NULL && checkBST(tree) && !contains(tree, value));
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
	}
	value = 50;
	f = fopen("test.dot", "w");
	bst_print_dot_values(tree, f, 1, value, -1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_delete3_before.png");
	tree = delete(tree, value);
	f = fopen("test.dot", "w");
	bst_print_dot(tree, f, 1);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_delete3_after.png");
	sd_assert("Problema5 - Test3 delete picat", height(tree) == 6 && tree != NULL && checkBST(tree) && !contains(tree, value));
	freeTree(&tree);

	return 0;
}

static char *test_lca() {
	Tree tree = NULL;
	int value1, value2, i, lca;
	FILE *f;

	for (i = 1; i <= test1[0]; i++) {
		tree = insert(tree, test1[i]);
	}
	value1 = 12;
	value2 = -8;
	lca = lowestCommonAncestor(tree, value1, value2);
	f = fopen("test.dot", "w");
	bst_print_dot_lca(tree, f, 1, value1, value2, lca);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_lca1.png");
	sd_assert("Problema6 - Test1 lca picat", lca == 7);
	freeTree(&tree);
	
	tree = NULL;
	for (i = 1; i <= test2[0]; i++) {
		tree = insert(tree, test2[i]);
	}
	value1 = 12;
	value2 = 35;
	lca = lowestCommonAncestor(tree, value1, value2);
	f = fopen("test.dot", "w");
	bst_print_dot_lca(tree, f, 1, value1, value2, lca);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_lca2.png");
	sd_assert("Problema6 - Test2 lca picat", lca == 25);
	freeTree(&tree);

	tree = NULL;
	for (i = 1; i <= test3[0]; i++) {
		tree = insert(tree, test3[i]);
	}
	value1 = 4;
	value2 = 43;
	lca = lowestCommonAncestor(tree, value1, value2);
	f = fopen("test.dot", "w");
	bst_print_dot_lca(tree, f, 1, value1, value2, lca);
	fclose(f);
	system("dot test.dot | neato -n -Tpng -o out_lca3.png");
	sd_assert("Problema6 - Test3 lca picat", lca == 35);
	freeTree(&tree);

	return 0;
}

static char *all_tests() {
	sd_run_test(test_insert, 2);
	sd_run_test(test_minmax, 1);
	sd_run_test(test_contains, 0.5);
	sd_run_test(test_height, 1);
	sd_run_test(test_size, 0.5);
	sd_run_test(test_mirror, 1.5);
	sd_run_test(test_delete, 2);
	sd_run_test(test_lca, 1.5);
	return 0;
}

static char *selective_tests(int argc, char **argv) {
	int i;
	int viz[10] = {0};
	for (i = 1; i < argc; i++) {
		if (viz[atoi(argv[i])]) {
			continue;
		}
		if (!strcmp(argv[i], "1")) {
			viz[1] = 1;
			sd_run_test(test_insert, 2);
		} else if (!strcmp(argv[i], "2")) {
			viz[2] = 1;
			sd_run_test(test_minmax, 1);
		} else if (!strcmp(argv[i], "3")) {
			viz[3] = 1;
			sd_run_test(test_contains, 0.5);
		} else if (!strcmp(argv[i], "4")) {
			viz[4] = 1;
			sd_run_test(test_height, 1);
		} else if (!strcmp(argv[i], "5")) {
			viz[5] = 1;
			sd_run_test(test_size, 0.5);
		} else if (!strcmp(argv[i], "6")) {
			viz[6] = 1;
			sd_run_test(test_mirror, 1.5);
		} else if (!strcmp(argv[i], "7")) {
			viz[7] = 1;
			sd_run_test(test_delete, 2);
		} else if (!strcmp(argv[i], "8")) {
			viz[8] = 1;
			sd_run_test(test_lca, 1.5);
		}
	}
	return 0;
}

int main(int argc, char **argv) {
	srand(time(NULL));
	char *result;
	if (argc == 1) {
		result = all_tests();
		if (result != 0) {
			printf("%s\n", result);
		} else {
			printf("Toate testele au trecut! Felicitari!\n");
		}
	} else {
		result = selective_tests(argc, argv);
		if (result != 0) {
			printf("%s\n", result);
		} else {
			printf("Toate testele selectate au trecut!\n");
		}
	}
	printf("Punctajul obtinut este: %.2lf\n", total_score);
	printf("Teste rulate: %d\n", tests_run);
	return result != 0;
}
