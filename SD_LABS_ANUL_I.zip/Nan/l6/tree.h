#ifndef _TREE_H_
#define _TREE_H_
/*
*	Created by Nan Mihai on 24.03.2020
*	Copyright (c) 2020 Nan Mihai. All rights reserved.
*	Laborator 6 - Structuri de date
*	Grupa 312CCb
*	Facultatea de Automatica si Calculatoare
*	Anul Universitar 2019-2020, Seria CC
*/

#include <stdio.h>
#include <stdlib.h>

/*
*	Reprezentarea unui arbore binar
*/
typedef int Item;

typedef struct node {
    Item value;
    struct node *left;
    struct node *right;
} TreeNode, *Tree;

void init(Tree *root, Item value);
Tree insert(Tree root, Item value);
Tree delete(Tree root, Item value);
void printPostorder(Tree root);
void printPreorder(Tree root);
void printInorder(Tree root);
int contains(Tree root, Item value);
Item minimum(Tree root);
Item maximum(Tree root);
void freeTree(Tree *root);
int size(Tree root);
int height(Tree root);
void mirror(Tree root);
Item lowestCommonAncestor(Tree root, Item value1, Item value2);
#endif
