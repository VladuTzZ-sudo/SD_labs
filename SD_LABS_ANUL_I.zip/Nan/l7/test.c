#include <stdio.h>
#include "trie.h"

int main() {
	Trie trie = NULL;
	trie = initTrie(' ', 0);
	trie = insertWord(trie, "ana", 0);
	trie = insertWord(trie, "are", 0);
	trie = insertWord(trie, "mere", 0);
	trie = insertWord(trie, "arena", 0);
	trie = insertWord(trie, "analfabet", 0);
	trie = insertWord(trie, "merge", 0);
	trie = insertWord(trie, "mereu", 0);
	trie = insertWord(trie, "anagrama", 0);
	trie = insertWord(trie, "areal", 0);
	trie = insertWord(trie, "ardeal", 0);
	trie = insertWord(trie, "ardelean", 0);
	trie = insertWord(trie, "anacolut", 0);
	trie = insertWord(trie, "ananas", 0);

	drawTrie(trie, "trie.png");
	//trie = deleteWord(trie, "ardelean", 0);
	//drawTrie(trie, "trie1.png");
	return 0;
}
