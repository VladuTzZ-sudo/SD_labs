#include "trie.h"

Trie initTrie(char value, bool end)
{
	Trie NouCopacel;
	NouCopacel = malloc(sizeof(struct trie));
	NouCopacel->end = end;
	NouCopacel->value = value;
	NouCopacel->sibling = NULL;
	NouCopacel->child = NULL;
	return NouCopacel;
}

int noOfKids(Trie trie)
{
	if (trie != NULL)
	{
		Trie Point;
		Point = malloc(sizeof(struct trie));
		if (trie->child != NULL)
		{
			Point = trie->child;
			int contor = 1;
			while (Point != NULL)
			{
				Point = Point->sibling;
				contor++;
			}
			return contor;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}
}

Trie insertChild(Trie trie, char value, bool end)
{
	Trie New;
	New = initTrie(value, end);
	if (trie == NULL)
	{
		trie = New;
		return trie;
	}
	else
	{
		if (trie->child == NULL)
		{
			trie->child = New;
		}
		else
		{
			Trie aux;
			aux = trie->child;
			while (aux->sibling != NULL && aux->value != value)
			{
				aux = aux->sibling;
			}
			if (aux->sibling == NULL)
			{
				aux->sibling = New;
				return trie;
			}
		}
	}
}

Trie getChild(Trie trie, char value)
{
	if (trie == NULL)
	{
		return trie;
	}
	else
	{
		if (trie->child == NULL)
		{
			return trie->child;
		}
		else
		{
			Trie aux;
			aux = trie->child;
			while (aux->sibling != NULL)
			{
				if (aux->value == value)
				{
					return aux;
				}
			}
			return NULL;
		}
	}
}

Trie insertWord(Trie trie, char *word, int index)
{
	int end;
	end = 2;
	if (index < strlen(word))
	{
		end = 0;
	}
	if (index == strlen(word) - 1)
	{
		end = 1;
	}
	if (trie == NULL && end < 2)
	{
		trie = initTrie(word[index], end);
		insertWord(trie, word, index + 1);
	}
	else
	{
		if (end < 2)
		{
			Trie New;
			trie = insertChild(trie, word[index], end);
			New = getChild(trie, word[index]);
			insertWord(New, word, index + 1);
		}
	}
	return trie;
}

bool containsWord(Trie trie, char *word, int index)
{
	return NULL;
}

void drawTrieHelper(Trie trie, FILE *stream)
{
	Trie tmp;
	if (trie == NULL)
	{
		return;
	}
	if (trie->end)
	{
		fprintf(stream, "    %ld[label=\"%c\", fillcolor=red]\n", (intptr_t)trie, trie->value);
	}
	else
	{
		fprintf(stream, "    %ld[label=\"%c\", fillcolor=blue]\n", (intptr_t)trie, trie->value);
	}
	tmp = trie->child;

	while (tmp != NULL)
	{
		fprintf(stream, "    %ld -> %ld \n", (intptr_t)trie, (intptr_t)tmp);
		drawTrieHelper(tmp, stream);
		tmp = tmp->sibling;
	}
}

void drawTrie(Trie trie, char *fileName)
{
	FILE *stream = fopen("test.dot", "w");
	char buffer[SIZE];
	fprintf(stream, "digraph TRIE {\n");
	fprintf(stream, "    node [fontname=\"Arial\", shape=circle, style=filled, fillcolor=yellow];\n");
	if (!trie)
		fprintf(stream, "\n");
	else if (!trie->child)
		fprintf(stream, "    %ld [label=\"%c\"];\n", (intptr_t)trie, trie->value);
	else
		drawTrieHelper(trie, stream);
	fprintf(stream, "}\n");
	fclose(stream);
	sprintf(buffer, "dot test.dot | neato -n -Tpng -o %s", fileName);
	system(buffer);
}

Trie deleteChild(Trie trie, char value)
{
	return NULL;
}

Trie deleteWord(Trie trie, char *word, int index)
{
	return NULL;
}

Trie freeTrie(Trie trie)
{
	return NULL;
}
