/*
*	Created by Nan Mihai on 03.03.2020
*	Copyright (c) 2020 Nan Mihai. All rights reserved.
*	Laborator 3 - Structuri de date
*	Grupa 314CD
*	Facultatea de Automatica si Calculatoare
*	Anul Universitar 2019-2020, Seria CD
*/
#include "DoubleLinkedList.h"

ListNode *createListNode(T value) {
	ListNode *node = (ListNode*) malloc(sizeof(ListNode));
	node->value = value;
	node->prev = NULL;
	node->next = NULL;
	return node;
}

List nill(void) {
	List list;
	list.first = list.last = NULL;
	return list;
}

/*
*	Funcție care întoarce o listă cu un singur nod, având valoarea value
*		- alocă memorie
*		- atribuie valoarea
*		- marchează finalul
*		- marchează începutul
*/
List createList(T value) {
	List list;
	ListNode *Nou = createListNode(value);
	//Nou = malloc(sizeof(ListNode));
	//Nou->next = Nou->prev = NULL;
	//Nou->value = value;
	list.first = Nou;
	list.last = Nou;
	return list;
}

/*
*	Funcție care verifică dacă o listă este vidă
*		- 1 dacă lista este vidă
*		- 0 altfel
*/
int isEmpty(List list) {
	if ( list.first == NULL )
		return 1;
	return 0;
}

/*
*	Funcție care inserează valoarea value în listă la poziția pos daca este validă
*		- funcția va avea ca rezultat noua listă
*		- pot exista duplicate în listă
*		- sunt tratate toate cazurile (first poate fi NULL)
*		- trebuie modificat last dacă inserăm la final
*/
List insertAt(List list, T value, int pos) {
	ListNode aux;
	aux = list.first;
	if ( aux.value == NULL ){
		aux = createListNode(value);
		list.first = aux;
		list.last = aux;
		return list;
	}
	else{
		int i = 1;
		while ( aux != NULL && i < pos){
			aux = aux.next;
			i++;
		}
	}
}

/*
*	Funcție care verifică dacă value apare sau nu în listă
*		- 1 dacă valoarea există
*		- 0 altfel
*/
int contains(List list, T value) {
	// TODO 4
	return 0;
}

/*
*	Funcție care șterge prima apariție a elementului value din listă
*		- rezultatul o să fie lista rezultată după ștergere
*		- funcția trebuie să dealoce memoria nodului șters
*/
List deleteOnce(List list, T value) {
	// TODO 5
	return list;
}

/*
*	Funcție care determină lungimea listei
*/
int length(List list) {
	// TODO 6
	return -1;
}

/*
*	Funcție care verifică dacă o listă este palindrom
*		- 1 dacă lista este palindrom
*		- 0 altfel
*	Listă palindrom: lista este egală cu reverse-ul ei (ex. NULL<-1<->2<->1->NULL, NULL<-1<->2<->2<->1->NULL)	
*/
int isPalindrome(List list) {
	// TODO 7
	return 0;
}

/*
*	Funcție care șterge o listă, dealocându-i întreaga memorie
*		- rezultatul funcției o să fie lista vidă
*/
List destroyList(List list) {
	// TODO 8
	return list;
}

void drawList(List l, char *name) {
	int i;
	FILE *stream;
	char *buffer;
	ListNode *tmp;

	if (l.first == NULL || name == NULL) {
		stream = fopen("list.dot", "w");
		fprintf(stream, "digraph foo {\n");
		fprintf(stream, "rankdir=LR;\nnode [shape=record, style=filled, fillcolor=yellow];\n");
		fprintf(stream, "b [label=\"NULL\", shape=box, fillcolor=red];\n");
		fprintf(stream, "}\n");
		fclose(stream);
		buffer = (char*) malloc(SIZE*sizeof(char));
		sprintf(buffer, "dot list.dot | neato -n -Tpng -o %s.png", name);
		system(buffer);
		free(buffer);
		return;
	}
	stream = fopen("list.dot", "w");
	fprintf(stream, "digraph foo {\n");
	fprintf(stream, "rankdir=LR;\nnode [shape=record, style=filled, fillcolor=yellow];\n");
	tmp = l.first;
	i = 1;
	fprintf(stream, "a0 [label=\"NULL\", shape=box, fillcolor=red];\n");
	while (tmp != NULL) {
		fprintf(stream, "a%d [label=\"{ <ref1> | <data> %d | <ref2>  }\", width=0.9];\n", i, tmp->value);
		tmp = tmp->next;
		i++;
	}
	fprintf(stream, "b [label=\"NULL\", shape=box, fillcolor=red];\n");
	tmp = l.first;
	i = 1;
	fprintf(stream, "a0:e -> a1:ref1:c      [arrowhead=vee, arrowtail=dot, dir=both, tailclip=false, color=white];");
	fprintf(stream, "a1:ref1:c -> a0      [arrowhead=vee, arrowtail=dot, dir=both, tailclip=false];");
	while (tmp->next != NULL) {
		fprintf(stream, "a%d:ref2:c -> a%d:ref1:c [arrowhead=vee, arrowtail=dot, dir=both, tailclip=false, arrowsize=0.9, color=red];\n", i, i+1);
		fprintf(stream, "a%d:ref1:c -> a%d:ref2:c [arrowhead=vee, arrowtail=dot, dir=both, tailclip=false, arrowsize=0.9, color=blue];\n", i+1, i);
		tmp = tmp->next;
		i++;
	}
	fprintf(stream, "a%d:ref2:c -> b      [arrowhead=vee, arrowtail=dot, dir=both, tailclip=false];\n", i);
	fprintf(stream, "}\n");
	fclose(stream);
	buffer = (char*) malloc(SIZE*sizeof(char));
	sprintf(buffer, "dot list.dot | neato -n -Tpng -o %s.png", name);
	system(buffer);
	free(buffer);
}

