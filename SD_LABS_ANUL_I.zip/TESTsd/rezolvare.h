#include "utils.h"

#define INDEX 4

void remove_items(List *head)
{
    List *aux;
    //aux = init_list(head, 0);
    int ok;
    ok = 0;
    if (head->next != NULL)
    {
        aux = head->next;
        if (aux->value % 2 == 1)
        {
            ok = 1;
        }
    }
    else
    {
        return;
    }
    List *aux2;
    //aux2 = init_list(head, 0);
    if (ok == 1)
    {
        if (aux->next != NULL)
        {
            aux->next->prev = aux->prev;
            aux->prev->next = aux->next;
            aux2 = aux->next;
            free(aux);
        }
        else
        {
            aux->prev->next = NULL;
            free(aux);
            return;
        }
        if (aux2 != NULL)
        {
            remove_items(aux2);
        }
    }
    if (aux->next != NULL && ok == 0)
    {
        remove_items(aux->next);
    }
}